import pandas as pandas
from django.contrib.auth import authenticate, login
from django.forms import model_to_dict
from django.http import JsonResponse
from django.shortcuts import render



# Create your views here.
from movie import models


def base(request):
    base_top = models.FilmRating.objects.filter(movie_title__isnull=False).order_by('-rating')[:51]
    return render(request, 'base.html',{"base_top":base_top})

def login(request):
    return render(request, 'login.html',{})

def user_login(request):
    if request.method == "POST":
        user_id = request.POST.get("inputUserid", "")
        pass_word = request.POST.get("inputPassword", "")

        user = authenticate(inputUserid=user_id, inputPassword=pass_word)
    if user:
        login(request, user)
        return render(request, "base.html", {"user": user})
    else:
        return render(request,  {"msg": "验证失败！"})



def cover(request):
    return render(request, 'cover.html',{})


def friends(request):
    friends_rec = models.FriendRecommendaton.objects.all()[:15]
    return render(request, 'friends.html',{'friends_rec':friends_rec})

def movierec(request):
    movie_rec = models.FilmRecommendation.objects.filter(user_id='36609500')
    return render(request, 'movie_rec.html',{'movie_rec':movie_rec})